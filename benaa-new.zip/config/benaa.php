<?php

return [

    'sf_url' => env('SF_URL', 'https://duconind.secure.force.com'),
    'fast_track_action' => env('FAST_TRACK_ACTION', 'https://webto.salesforce.com/servlet/servlet.WebToLead?encoding=UTF-8'),
    'APIKEY' => env('APIKEY', 'NzZlNWM2YWItNmY2My00YjVhLTgyZGQtZmIwNGQzNTNhNzRjOmU0MThiZmE4LTRiMDEtNGM0OC04ODY2LWVkYTI5YjJlMmI0Nw=='),
    'OUTLET' => env('OUTLET', '0c0f97e2-748a-492c-9ef1-f658257010aa'),
    'TOKENURL' => env('TOKENURL', 'https://api-gateway.ngenius-payments.com/identity/auth/access-token/'),
    'ORDERURL' => env('ORDERURL', 'https://api-gateway.ngenius-payments.com/transactions/outlets/'),
    'REALNAME' => env('REALNAME', 'NetworkInternational'),

];