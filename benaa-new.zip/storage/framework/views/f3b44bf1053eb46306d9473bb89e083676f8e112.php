

<?php $__env->startSection('title', '800Benaa | Page Not Found'); ?>

<?php $__env->startSection('content'); ?>

<div class="block">
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="col-12">
                <h1 class="about-us__title">Sorry, the server is not responding at the moment, Please try again!</h1>
                <div class="order-success__actions text-center">
                    <a href="<?php echo e(URL::to('/')); ?>" class="btn btn-xs btn-primary">Go To Home</a>
                </div>               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/errors/500.blade.php ENDPATH**/ ?>