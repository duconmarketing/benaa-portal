<?php $__env->startSection('title', '800Benaa | '.$category); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header__container container">
        <div class="page-header__breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                        <svg class="breadcrumb-arrow" width="6px" height="9px">
                        <use xlink:href="<?php echo e(asset('public/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                        </svg>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($category); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="block block-products block-products--layout--large-first" data-mobile-grid-columns="2">
    <div class="container">
        <div class="block-header">
            <h3 class="block-header__title"><?php echo e($category); ?></h3>
            <div class="block-header__divider"></div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="block">
                    <div class="products-view">
                        <div class="products-view__list products-list" data-layout="grid-3-sidebar" data-mobile-grid-columns="2" data-with-features="false">
                            <div class="products-list__body">
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="products-list__item">
                                        <div class="post-card post-card--layout--grid post-card--size--nl text-center">
                                            <div class="post-card__image">
                                                <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory['Name']))); ?>">
                                                    <img src="<?php echo e($subCategory['Image_URL__c']); ?>" alt="<?php echo e($subCategory['Name']); ?>">
                                                </a>
                                            </div>
                                            <div class="post-card__info">
                                                <div class="post-card__name text-center">
                                                    <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory['Name']))); ?>"><?php echo e($subCategory['Name']); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </div>
                        </div>                    
                    </div>
                </div>
            </div>        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-portal\resources\views/category.blade.php ENDPATH**/ ?>