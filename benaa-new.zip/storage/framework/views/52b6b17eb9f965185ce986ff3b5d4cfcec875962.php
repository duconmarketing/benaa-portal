<div class="block block-products block-products--layout--large-first" data-mobile-grid-columns="2">
    <div class="container">
    <div class="products-view__list products-list" data-layout="grid-3-sidebar" data-with-features="false" data-mobile-grid-columns="2">
            <div class="products-list__body">
                <?php if(count($result) > 0): ?>
                    <div class="row" style="min-width:100%;">
                        <div class="col-md-3">
                            
                        </div>
                        <div class="col-md-9">
                            <div class="row">
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                                <div class="products-list__item">
                                    <div class="product-card product-card--hidden-actions ">
                                        <div class="product-card__image product-image">
                                            <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e($row['Id']); ?>" class="product-image__body">
                                                <img class="product-image__img" src="<?php echo e($row['Product2']['Default_Image_URL__c']); ?>" alt="">
                                            </a>
                                        </div>
                                        <div class="product-card__info">
                                            <div class="product-card__name">
                                                <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e($row['Id']); ?>" class="a_title_ajx"><?php echo e($row['Name']); ?></a>
                                            </div>                                 
                                        </div>
                                        <div class="product-card__actions">
                                            <div class="product-card__availability">
                                                Availability: <span class="text-success">In Stock</span>
                                            </div>
                                            <div class="product-card__prices">
                                                AED <?php echo e($row['UnitPrice']); ?>

                                            </div>
                                            <div class="product-card__buttons">
                                                <button class="btn btn-primary product-card__addtocart" data-id="<?php echo e($row['Id']); ?>" data-name="<?php echo e($row['Name']); ?>" data-price="<?php echo e($row['UnitPrice']); ?>" data-image="<?php echo e($row['Product2']['Default_Image_URL__c']); ?>" data-link="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e($row['Id']); ?>" type="submit">
                                                    <small>Add to Cart</small>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>                   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>                        
                    </div>      
                <?php else: ?>
                    <li>
                        No results!
                    </li>        
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/search-suggestions.blade.php ENDPATH**/ ?>