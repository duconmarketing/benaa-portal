

<?php $__env->startSection('title', '800Benaa | '.$category); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header__container container" style="background-color: #fff;">
        <div class="page-header__breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(URL::to('/')); ?>">HOME</a>
                        <svg class="breadcrumb-arrow" width="6px" height="9px">
                        <use xlink:href="<?php echo e(asset('public/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                        </svg>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($category); ?></li>
                </ol>
            </nav>
        </div>
        <div class="page-header__title">
            <h1><?php echo e(ucwords(strtolower($category))); ?></h1>
        </div>
    </div>
</div>
<div class="container" style="background-color: #fff;">
    <div class="shop-layout shop-layout--sidebar--start">
        <div class="shop-layout__sidebar">
            <div class="block block-sidebar block-sidebar--offcanvas--mobile">
                <div class="block-sidebar__backdrop"></div>
                <div class="block-sidebar__body">
                    <div class="block-sidebar__header">
                        <div class="block-sidebar__title">Filters</div>
                        <button class="block-sidebar__close" type="button">
                            <svg width="20px" height="20px">
                                <use xlink:href="images/sprite.svg#cross-20"></use>
                            </svg>
                        </button>
                    </div>

                    <div class="block-sidebar__item">
                        <div class="widget-filters__list">
                            <div class="widget-filters__item">
                                <div class="filter filter--opened">
                                    <div class="filter__body" >
                                        <div class="filter__container">
                                            <!-- category from ajax -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="shop-layout__content">
            <div class="block">
                <div class="products-view">
                    <div class="products-view__list products-list" data-layout="grid-3-sidebar" data-with-features="false" data-mobile-grid-columns="2">
                        <div class="products-list__body">
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="products-list__item">
                                    <div class="product-card text-center">
                                        <div class="post-card__image">
                                            <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e($subCategory['Id']); ?>">
                                                <img src="<?php echo e($subCategory['Image_URL__c']); ?>" alt="<?php echo e($subCategory['Name']); ?>">
                                            </a>
                                        </div>
                                        <div class="post-card__info mt-2 mb-2">
                                            <div class="post-card__name text-center">
                                                <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e($subCategory['Id']); ?>"><?php echo e($subCategory['Name']); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="products-view__pagination">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    const setSideBar = function(html) {
        if (html) {
            $('.filter__container').html(html);
        }
    };
    $.ajax({
        url: BaseUrl + '/cat-list',
        method: 'GET',
        data:{},
        success: function(data) {
            xhr = null;
            setSideBar(data);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/category.blade.php ENDPATH**/ ?>