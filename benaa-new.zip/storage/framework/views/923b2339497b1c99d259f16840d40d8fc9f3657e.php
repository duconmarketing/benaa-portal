

<?php $__env->startSection('title', 'Download 800Benaa Complete Catalogue - Your Online Hardware Store'); ?>

<?php $__env->startSection('content'); ?>
    <!-- quickview-modal -->
    <div id="quickview-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content"></div>
        </div>
    </div>
    <!-- quickview-modal / end -->
<div class="page-header">
    <div class="page-header__container container">
        <div class="page-header__breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                        <svg class="breadcrumb-arrow" width="6px" height="9px">
                            <use xlink:href="<?php echo e(asset('public/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                        </svg>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Catalog</li>
                </ol>
            </nav>
        </div>
    </div>
    </div>
    <div class="checkout block">
        <div class="container">
         <iframe allowfullscreen="" allow="fullscreen" style="border:none;width:100%;height:1000px;" src="//e.issuu.com/embed.html?d=800benaa_catalogue&amp;hideIssuuLogo=true&amp;u=duconind"></iframe>
        </div>
    </div>

<script>
    // to show fast track form popup 
    const modal = $('#quickview-modal');
    const timeout = setTimeout(function() {
        res = $.ajax({
            url: '<?php echo e(URL("catalog-popup")); ?>',
            success: function(data) {
                modal.find('.modal-content').html(data);
                modal.modal('show');
                modal.find('.quickview__close').on('click', function() {
                    modal.modal('hide');
                });
            }
        });
    }, 1000);    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/catalog.blade.php ENDPATH**/ ?>