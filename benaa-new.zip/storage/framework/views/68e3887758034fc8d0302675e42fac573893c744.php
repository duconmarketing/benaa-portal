<ul class="suggestions__list">
    <?php if(count($result) > 0): ?>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="suggestions__item">                
                    <div class="suggestions__item-image product-image">
                        <div class="product-image__body">
                            <!-- <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $row['Name']))); ?>">
                                <img class="product-image__img" src="<?php echo e($row['Product2']['Default_Image_URL__c']); ?>" alt="">
                            </a> -->
                            <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(urlencode($category . '#' . $subCategory. '#'. $row['Name'])); ?>">
                                <img class="product-image__img" src="<?php echo e($row['Product2']['Default_Image_URL__c']); ?>" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="suggestions__item-info">
                        <!-- <a class="suggestions__item-name" href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $row['Name']))); ?>">
                            <?php echo e($row['Name']); ?>

                        </a> -->
                        <a class="suggestions__item-name" href="<?php echo e(URL::to('/')); ?>/product/cat/subcat/<?php echo e(urlencode(str_replace('%', '$', $category . '#' . $subCategory. '#'. $row['Name']))); ?>">
                            <?php echo e($row['Name']); ?>

                        </a>
                        <div class="suggestions__item-meta">SKU: 83690/32</div>
                    </div>
                    <div class="suggestions__item-price">
                        AED <?php echo e(number_format($row['UnitPrice'], 2)); ?>

                    </div>
                    <!-- <div class="suggestions__item-actions">
                        <button type="button" title="Add to cart" class="btn btn-primary btn-sm btn-svg-icon">
                            <svg width="16px" height="16px">
                                <use xlink:href="images/sprite.svg#cart-16"></use>
                            </svg>
                        </button>
                    </div> -->
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    <?php else: ?>
        <li>
            No results!
        </li>        
    <?php endif; ?>
</ul><?php /**PATH C:\xampp7.4\htdocs\benaa-portal\resources\views/search-suggestions.blade.php ENDPATH**/ ?>