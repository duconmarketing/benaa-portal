<div class="filter-categories">
    <ul class="filter-categories__list">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="filter-categories__item filter-categories__item--current">
                <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e($cat['Id']); ?>"><?php echo e(ucwords(strtolower($cat['Name']))); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/catList.blade.php ENDPATH**/ ?>