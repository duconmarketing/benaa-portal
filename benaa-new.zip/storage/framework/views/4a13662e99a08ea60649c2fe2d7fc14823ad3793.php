<?php $__env->startSection('title', '800Benaa | '.$category); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            <!-- section title -->
            <div class="col-md-12">
                <div class="section-title">
                    <?php if(count($results) > 0): ?>
                    <h3 class="title">Products in '<?php echo e($category); ?>'</h3>
                    <?php else: ?>
                    <h3 class="title">No Products in '<?php echo e($category); ?>'</h3>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /section title -->

            <!-- Products tab & slick -->
            <div class="col-md-12">
                <div class="row">
                    <div class="products-tabs">
                        <div class="row">
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="product">
                                    <div class="product-img">
                                        <img src="<?php echo e(asset('public/img/product01.png')); ?>" alt="">
                                        <div class="product-label">
                                        </div>
                                    </div>
                                    <div class="product-body">
                                        <p class="product-category">Category</p>
                                        <h3 class="product-name"><a href="#"><?php echo e($product['Name']); ?></a></h3>

                                    </div>
                                </div>    
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div id="slick-nav-1" class="products-slick-nav"></div>
                    </div>
                </div>
            </div>
            <!-- Products tab & slick -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaaportal-live\resources\views/category.blade.php ENDPATH**/ ?>