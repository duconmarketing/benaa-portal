    <style>
        .style1{font-family: Arial, Helvetica, sans-serif;font-size:10pt;width: 100%;}
        .cartTable{border: 1px solid #fffcc;border-collapse: collapse;}
        .cartTable tr{border: 1px solid #fffcc;}
        .cartTable td{border: 1px solid #fffcc;}
    </style>
<table width="100%">
    <tr>
        <td valign="left" style="text-align:left"><img src="<?php echo e(asset('public/images/Benaa_Logo.png')); ?>" /></td>
        <td valign="right" style="text-align:right"><h1>QUOTATION</h1></td>
    </tr>
    <tr>
        <td>
            Ducon Industries<br/>
            National Industries Park<br/>
            TP010225, PO Box 262394<br/>
            Dubai, UAE<br/>
        </td>
        <td style="text-align:right">
            Phone: +971 4 8235882<br/>
            Fax: +971 4 880 6980<br/>
            Email: sales@800benaa.com<br/>
            Website: www.800benaa.com<br/>
        </td>
    </tr>
</table>
<br/>
<hr/>
<br/>
<table width="100%" style="font-size: 13px;">
    <tr>
        <td style="text-align:left">
            <table>
                <tr>
                    <td>To:</td>
                    <td></td>
                </tr>
                <tr>
                    <td>Mr/Ms. </td>
                    <td><?php echo e($details->get('firstname'). ' '. $details->get('lastname')); ?></td>
                </tr>
                <tr>
                    <td>Phone: </td>
                    <td><?php echo e($details->get('phone')); ?></td>
                </tr>
                <tr>
                    <td>Email: </td>
                    <td><?php echo e($details->get('email')); ?></td>
                </tr>
                <tr>
                    <td>Company: </td>
                    <td><?php echo e($details->get('company') == ''? NA : $details->get('company')); ?></td>
                </tr>
                <tr>
                    <td>Address: </td>
                    <td><?php echo e($details->get('apartment') .', '. $details->get('street'). ', '.$details->get('region').', '.$details->get('country')); ?> </td>
                </tr>
            </table>
        </td>
        <td style="text-align:right">
            <table width="100%" style="text-align:right">
                <tr>
                    <td>Date: </td>
                    <td><?php echo e(date('M-y-d')); ?></td>
                </tr>
                <tr>
                    <td>Expiry Date:</td>
                    <td><?php echo e(date('M-y-d', strtotime('+7 days'))); ?></td>
                </tr>
                <tr>
                    <td>Quotation Ref: </td>
                    <td>EGL<?php echo e(date('Y-m-d H:i:s')); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>


    <?php if(count(\Cart::content()) > 0): ?>
        <table class="style1 cartTable" style="margin-top:20px;">
            <tr>
                <td>No</td>
                <td>Product</td>
                <td>Price</td>
                <td>Quantity</td>
                <td>Total</td>
            </tr>
        <?php $__currentLoopData = \Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e(ucwords(strtolower($items->name))); ?></td>
                <td><?php echo e($items->price); ?></td>
                <td><?php echo e($items->qty); ?></td>
                <td><?php echo e($items->total); ?></td>
            </tr>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php else: ?>
        <h2>Empty Cart!</h2>
    <?php endif; ?>

    <div class="dropcart__totals">
        <table>
            <tr>
                <th>Subtotal</th>
                <td>AED <?php echo e(\Cart::subtotal()); ?></td>
            </tr>
            <!-- <tr>
                <th>Shipping</th>
                <td>Not Calculated</td>
            </tr> -->
            <tr>
                <th>Tax</th>
                <td>AED <?php echo e(\Cart::tax()); ?></td>
            </tr>
            <tr>
                <th>Total</th>
                <td>AED <?php echo e(\Cart::total()); ?></td>
            </tr>
        </table>
    </div><?php /**PATH C:\xampp7.4\htdocs\benaa-portal\resources\views/getquote.blade.php ENDPATH**/ ?>