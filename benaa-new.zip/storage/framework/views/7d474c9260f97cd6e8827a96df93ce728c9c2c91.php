<div class="filter-categories">
    <ul class="filter-categories__list">
        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="filter-categories__item filter-categories__item--current">
                <a href="<?php echo e($subcat['Id']); ?>"><?php echo e(ucwords(strtolower($subcat['Name']))); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\xampp7.4\htdocs\benaa-new\resources\views/subCatList.blade.php ENDPATH**/ ?>