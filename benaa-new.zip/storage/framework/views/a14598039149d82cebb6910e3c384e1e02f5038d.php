<?php $__env->startSection('title', 'Search result for '.$key); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header__container container">
        <div class="page-header__breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                        <svg class="breadcrumb-arrow" width="6px" height="9px">
                        <use xlink:href="<?php echo e(asset('public/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                        </svg>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Search</li>
                </ol>
            </nav>
        </div>
        <div class="page-header__title">
            <?php if(count($results) > 0): ?>
            <h3 class="title">Search Results for '<?php echo e($key); ?>'</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="block">
                <div class="products-view">                                        
                    <?php if(count($results) > 0): ?>
                        <div class="products-view__list products-list" data-layout="grid-4-full" data-with-features="false" data-mobile-grid-columns="2">
                            <div class="products-list__body">
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="products-list__item">
                                        <div class="product-card product-card--hidden-actions ">
                                            <button class="product-card__quickview" type="button">
                                                <svg width="16px" height="16px">
                                                <use xlink:href="images/sprite.svg#quickview-16"></use>
                                                </svg>
                                                <span class="fake-svg-icon"></span>
                                            </button>
                                            <div class="product-card__badges-list">
                                                <div class="product-card__badge product-card__badge--new">New</div>
                                            </div>
                                            <div class="product-card__image product-image">
                                            <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $product['Name']))); ?>" class="product-image__body">
                                                    <img class="product-image__img" src="<?php echo e($product['Product2']['Default_Image_URL__c']); ?>" alt="">
                                                </a>
                                            </div>
                                            <div class="product-card__info">
                                                <div class="product-card__name">
                                                    <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $subCategory))); ?>/<?php echo e(strtolower(str_replace(' ', '-', $product['Name']))); ?>"><?php echo e($product['Name']); ?> </a>
                                                </div>
                                                <div class="product-card__rating">
                                                    <div class="product-card__rating-stars">
                                                        <div class="rating">
                                                            <div class="rating__body">
                                                                <svg class="rating__star rating__star--active" width="13px" height="12px">
                                                                <g class="rating__fill">
                                                                <use xlink:href="images/sprite.svg#star-normal"></use>
                                                                </g>
                                                                <g class="rating__stroke">
                                                                <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                                </g>
                                                                </svg>
                                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                                    <div class="rating__fill">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                    <div class="rating__stroke">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                </div>
                                                                <svg class="rating__star rating__star--active" width="13px" height="12px">
                                                                <g class="rating__fill">
                                                                <use xlink:href="images/sprite.svg#star-normal"></use>
                                                                </g>
                                                                <g class="rating__stroke">
                                                                <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                                </g>
                                                                </svg>
                                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                                    <div class="rating__fill">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                    <div class="rating__stroke">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                </div>
                                                                <svg class="rating__star rating__star--active" width="13px" height="12px">
                                                                <g class="rating__fill">
                                                                <use xlink:href="images/sprite.svg#star-normal"></use>
                                                                </g>
                                                                <g class="rating__stroke">
                                                                <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                                </g>
                                                                </svg>
                                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                                    <div class="rating__fill">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                    <div class="rating__stroke">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                </div>
                                                                <svg class="rating__star rating__star--active" width="13px" height="12px">
                                                                <g class="rating__fill">
                                                                <use xlink:href="images/sprite.svg#star-normal"></use>
                                                                </g>
                                                                <g class="rating__stroke">
                                                                <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                                </g>
                                                                </svg>
                                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                                    <div class="rating__fill">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                    <div class="rating__stroke">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                </div>
                                                                <svg class="rating__star " width="13px" height="12px">
                                                                <g class="rating__fill">
                                                                <use xlink:href="images/sprite.svg#star-normal"></use>
                                                                </g>
                                                                <g class="rating__stroke">
                                                                <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                                </g>
                                                                </svg>
                                                                <div class="rating__star rating__star--only-edge ">
                                                                    <div class="rating__fill">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                    <div class="rating__stroke">
                                                                        <div class="fake-svg-icon"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="product-card__rating-legend">9 Reviews</div>
                                                </div>
                                                <ul class="product-card__features-list">
                                                    <li>Speed: 750 RPM</li>
                                                    <li>Power Source: Cordless-Electric</li>
                                                    <li>Battery Cell Type: Lithium</li>
                                                    <li>Voltage: 20 Volts</li>
                                                    <li>Battery Capacity: 2 Ah</li>
                                                </ul>
                                            </div>
                                            <div class="product-card__actions">
                                                <div class="product-card__availability">
                                                    Availability: <span class="text-success">In Stock</span>
                                                </div>
                                                <div class="product-card__prices">
                                                    AED <?php echo e($product['UnitPrice']); ?>

                                                </div>
                                                <form action="<?php echo e(URL::to('/addtocart')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($product['Id']); ?>" />
                                                    <input type="hidden" name="name" value="<?php echo e($product['Name']); ?>" />
                                                    <input type="hidden" name="price" value="<?php echo e($product['UnitPrice']); ?>" />
                                                    <input type="hidden" name="image" value="<?php echo e($product['Product2']['Default_Image_URL__c']); ?>" />
                                                    <input type="hidden" name="link" value="<?php echo e(URL::to('/')); ?>/product/<?php echo e($category); ?>/<?php echo e($category); ?>/<?php echo e($product['Id']); ?>" />

                                                    <div class="product-card__buttons">
                                                        <button class="btn btn-primary product-card__addtocart" type="submit">Add To Cart</button>
                                                        <button class="btn btn-secondary product-card__addtocart product-card__addtocart--list" type="button">Add To Cart</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>                
                        </div>
                    <?php echo e($results->appends($_GET)->links()); ?>

                    <?php else: ?>
                        <h2>No Results !!!</h2>
                    <?php endif; ?>
                </div>
            </div>                                    
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-portal\resources\views/searchResult.blade.php ENDPATH**/ ?>