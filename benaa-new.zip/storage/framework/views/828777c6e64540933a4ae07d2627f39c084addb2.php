

<?php $__env->startSection('title', '800Benaa | Shop'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="page-header__container container">
        <div class="page-header__breadcrumb">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(URL::to('/')); ?>">Home</a>
                        <svg class="breadcrumb-arrow" width="6px" height="9px">
                        <use xlink:href="<?php echo e(asset('public/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                        </svg>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Shop</li>
                </ol>
            </nav>
        </div>
        <div class="page-header__title">
            <h1>Shop</h1>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="block">
                <div class="products-view">
                    <div class="products-view__list products-list" data-layout="grid-3-sidebar" data-mobile-grid-columns="2" data-with-features="false">
                        <div class="products-list__body">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="products-list__item">
                                    <div class="post-card post-card--layout--grid post-card--size--nl text-center">
                                        <div class="post-card__image">
                                            <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category['Name']))); ?>">
                                                <img src="<?php echo e($category['Image_URL__c']); ?>" alt="<?php echo e($category['Name']); ?>">
                                            </a>
                                        </div>
                                        <div class="post-card__info">
                                            <div class="post-card__name text-center">
                                                <a href="<?php echo e(URL::to('/')); ?>/product/<?php echo e(strtolower(str_replace(' ', '-', $category['Name']))); ?>"><?php echo e($category['Name']); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </div>
                    </div>                    
                </div>
            </div>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.4\htdocs\benaa-portal\resources\views/shop.blade.php ENDPATH**/ ?>